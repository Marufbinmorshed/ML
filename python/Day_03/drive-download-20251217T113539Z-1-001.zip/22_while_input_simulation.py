# While loop with simulated input
numbers = [3, 6, 9, 12]
i = 0
while i < len(numbers):
    print("Value:", numbers[i])
    i += 1
