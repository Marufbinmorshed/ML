# Controlled infinite loop
i = 1
while True:
    print(i)
    if i == 5:
        break
    i += 1
