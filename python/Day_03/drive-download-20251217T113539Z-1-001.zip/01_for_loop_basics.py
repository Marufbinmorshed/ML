# Basic for loop
for i in range(1, 11):
    print("Number:", i)
