# While loop with list
nums = [10, 20, 30, 40]
i = 0
while i < len(nums):
    print(nums[i])
    i += 1
