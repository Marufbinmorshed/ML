# Multiplication table
n = 5
for i in range(1, 11):
    print(n, "x", i, "=", n*i)
