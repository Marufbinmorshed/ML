# Sum of matrix elements
matrix = [[1,2],[3,4]]
total = 0
for row in matrix:
    for val in row:
        total += val
print("Matrix Sum:", total)
