# Square elements of list
nums = [1, 2, 3, 4]
squares = []
for n in nums:
    squares.append(n*n)
print(squares)
