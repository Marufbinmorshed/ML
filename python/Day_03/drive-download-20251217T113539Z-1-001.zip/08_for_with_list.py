# Loop through a list
fruits = ["apple", "banana", "mango"]
for fruit in fruits:
    print(fruit)
