# Nested for loop
for i in range(1, 4):
    for j in range(1, 4):
        print(i, j)
