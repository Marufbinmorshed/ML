# Loop through a set
colors = {"red", "green", "blue"}
for c in colors:
    print(c)
