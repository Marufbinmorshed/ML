# Factorial using while loop
n = 5
fact = 1
while n > 0:
    fact *= n
    n -= 1
print("Factorial:", fact)
