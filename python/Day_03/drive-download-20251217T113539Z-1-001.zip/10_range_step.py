# range with step
for i in range(0, 21, 2):
    print(i)
