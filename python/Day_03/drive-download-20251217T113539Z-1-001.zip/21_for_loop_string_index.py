# Loop through string using index
text = "iteration"
for i in range(len(text)):
    print(i, text[i])
