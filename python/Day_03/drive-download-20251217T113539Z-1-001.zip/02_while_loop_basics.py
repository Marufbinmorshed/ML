# Basic while loop
count = 1
while count <= 5:
    print("Count:", count)
    count += 1
