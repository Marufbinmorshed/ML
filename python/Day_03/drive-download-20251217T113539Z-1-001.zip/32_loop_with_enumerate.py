# Loop using enumerate
names = ["A", "B", "C"]
for index, name in enumerate(names):
    print(index, name)
