# Loop through dictionary
student = {"name": "Rahim", "age": 20, "dept": "CSE"}
for key, value in student.items():
    print(key, ":", value)
