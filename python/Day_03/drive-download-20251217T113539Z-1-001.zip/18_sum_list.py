# Sum of list elements
nums = [1, 2, 3, 4, 5]
total = 0
for n in nums:
    total += n
print("Sum:", total)
